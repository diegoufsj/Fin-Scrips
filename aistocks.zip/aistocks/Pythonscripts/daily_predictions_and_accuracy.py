#!/usr/bin/python


from network_functions import run_predictions
#from network_functions import update_accuracy


#update_accuracy()

run_predictions()
