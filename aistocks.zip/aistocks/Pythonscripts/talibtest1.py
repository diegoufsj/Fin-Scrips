
from pandas import *
print pandas.util.terminal.get_terminal_size()
