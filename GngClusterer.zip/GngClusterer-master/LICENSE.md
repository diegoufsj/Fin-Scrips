# Important Info regarding the GNG Clusterer #

There are not guarantees with this software. Use at your own risk. I am not responsible for any investment based on the results of this program. Please read the README for more information