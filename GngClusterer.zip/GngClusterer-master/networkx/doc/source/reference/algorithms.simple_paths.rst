************
Simple Paths
************

.. automodule:: networkx.algorithms.simple_paths
.. autosummary::
   :toctree: generated/

   all_simple_paths
