Files:
combined_data.txt #All Data combined into one text file
Function.txt #functions wrote to processdata
Holiday-list $list to be used by Workdays
label.txt #text file containing labels for data using window -11,12
main.py #main file to run
parsedata.py #file used to remove emptylines from data
pre_prossed_data.txt #data with stopwords remove and bigrams added
Readme.txt #this file
stopwords.txt # stopeords of 500 most common words not used but included
workdays.py # python code from Odysseas Tsatalos all credit goes to him 

Folders:
not_needed : includes file previously used for gathering data and testing
pull_data: contains csv file with financial data gotten from Yahoo
workdays-master: Workday files downloaded from github al credit goes to Odysseas Tsatalos.