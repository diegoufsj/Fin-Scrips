#!/usr/bin/python

#from network_functions import create_net
#from network_functions import calc_test_accuracy
#from network_functions import run_predictions
#from network_functions import update_ndc
import network_functions
#net_id = 10
#row = 10
#prediction = 10
#target = 10

#save_tests(net_id, row, prediction, target)
#print create_net_record(9)

##test = create_net(191, 6)
#test = create_net(191, 8)
#test = create_net(191, 5)
#test = create_net(191, 4)
#test = create_net(191, 7)
#test = create_net(191, 7)
#test = calc_test_accuracy()
#network_functions.run_predictions()
#test = update_ndc()
network_functions.update_stock_data()
#network_functions.calc_signals()
#network_functions.update_indecies_data()
